# Anne's Daily Quiz
Next.js + Upstash Redis (storage) + Google Gemini free tier (writes the questions) + Resend (email). Deploy on Vercel.

1. Push this folder to a GitHub repo, import it in Vercel.
2. Vercel > Storage > add **Upstash Redis** (connects its variables automatically).
3. Add env vars: `GEMINI_API_KEY` (free, from aistudio.google.com), `RESEND_API_KEY`, `QUIZ_FROM_EMAIL` (an address on a domain verified in Resend), `APP_URL` (your site URL), optional `CRON_SECRET`.
4. Redeploy, open the site in Safari, set Settings, then Share > Add to Home Screen.
Cron runs daily at 20:00 UTC (7am Melbourne summer time); the app skips days that are not due.
