import { todayKey } from "@/lib/dates";
import { getEdition } from "@/lib/quiz";
import { db } from "@/lib/store";
import type { Result } from "@/lib/types";
export const dynamic = "force-dynamic";
export const maxDuration = 60;
export async function GET() {
  try {
    const date = todayKey();
    const edition = await getEdition(date);
    const result = await db().hget<Result>("results", date);
    return Response.json({ edition, result });
  } catch (e: any) { return Response.json({ error: e.message }, { status: 500 }); }
}
