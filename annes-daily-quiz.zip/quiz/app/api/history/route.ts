import { computeStats, getResults } from "@/lib/store";
export const dynamic = "force-dynamic";
export async function GET() {
  try { const results = await getResults(); return Response.json({ results, stats: computeStats(results) }); }
  catch (e: any) { return Response.json({ error: e.message }, { status: 500 }); }
}
