import { getEdition } from "@/lib/quiz";
import { computeStats, db, getResults } from "@/lib/store";
import type { Result } from "@/lib/types";
export const dynamic = "force-dynamic";
export const maxDuration = 60;
export async function POST(req: Request) {
  try {
    const { date, answers } = await req.json();
    const ed = await getEdition(date);
    const byArea: Record<string, [number, number]> = {};
    let score = 0;
    ed.questions.forEach((q, i) => {
      const hit = answers[i] === q.answer;
      const a = (byArea[q.area] ??= [0, 0]); a[1]++; if (hit) { a[0]++; score++; }
    });
    const result: Result = { date, difficulty: ed.difficulty, score, total: ed.questions.length, byArea, answers };
    await db().hset("results", { [date]: result });
    return Response.json({ result, stats: computeStats(await getResults()) });
  } catch (e: any) { return Response.json({ error: e.message }, { status: 500 }); }
}
