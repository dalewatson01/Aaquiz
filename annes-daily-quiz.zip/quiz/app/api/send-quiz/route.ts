import { Resend } from "resend";
import { daysBetween, longDate, todayKey } from "@/lib/dates";
import { renderEmail } from "@/lib/email";
import { getEdition } from "@/lib/quiz";
import { db, getSettings } from "@/lib/store";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

async function run(manual: boolean) {
  try {
    if (!process.env.RESEND_API_KEY) throw new Error("RESEND_API_KEY is not set.");
    const s = await getSettings();
    const date = todayKey();
    if (!manual) {
      const last = await db().get<string>("lastSent");
      if (last && daysBetween(last, date) < s.everyDays) return Response.json({ skipped: "Not due yet." });
    }
    const ed = await getEdition(date);
    const { error } = await new Resend(process.env.RESEND_API_KEY).emails.send({
      from: process.env.QUIZ_FROM_EMAIL ?? "Anne's Daily Quiz <onboarding@resend.dev>",
      to: s.email, subject: `Anne's Daily Quiz: ${longDate(date)}`, html: renderEmail(ed, s.name, process.env.APP_URL),
    });
    if (error) throw new Error(error.message);
    await db().set("lastSent", date);
    return Response.json({ sent: true, to: s.email });
  } catch (e: any) { return Response.json({ error: e.message }, { status: 500 }); }
}
export async function GET(req: Request) {
  const secret = process.env.CRON_SECRET;
  if (secret && req.headers.get("authorization") !== `Bearer ${secret}`) return Response.json({ error: "Unauthorised" }, { status: 401 });
  return run(false);
}
export async function POST() { return run(true); }
