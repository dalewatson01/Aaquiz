import nodemailer from "nodemailer";
import { daysBetween, longDate, todayKey } from "@/lib/dates";
import { renderEmail } from "@/lib/email";
import { getEdition } from "@/lib/quiz";
import { db, getSettings } from "@/lib/store";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

async function run(manual: boolean) {
  try {
    const user = process.env.GMAIL_USER, pass = process.env.GMAIL_APP_PASSWORD;
    if (!user || !pass) throw new Error("GMAIL_USER and GMAIL_APP_PASSWORD are not set.");
    const s = await getSettings();
    const date = todayKey();
    if (!manual) {
      const last = await db().get<string>("lastSent");
      if (last && daysBetween(last, date) < s.everyDays) return Response.json({ skipped: "Not due yet." });
    }
    const ed = await getEdition(date);
    const mail = nodemailer.createTransport({ service: "gmail", auth: { user, pass: pass.replace(/\s/g, "") } });
    await mail.sendMail({
      from: `Anne's Daily Quiz <${user}>`, to: s.email,
      subject: `Anne's Daily Quiz: ${longDate(date)}`, html: renderEmail(ed, s.name, process.env.APP_URL),
    });
    await db().set("lastSent", date);
    return Response.json({ sent: true, to: s.email });
  } catch (e: any) { return Response.json({ error: e.message }, { status: 500 }); }
}
export async function GET(req: Request) {
  const secret = process.env.CRON_SECRET;
  if (secret && req.headers.get("authorization") !== `Bearer ${secret}`) return Response.json({ error: "Unauthorised" }, { status: 401 });
  return run(false);
}
export async function POST() { return run(true); }
