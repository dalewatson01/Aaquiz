import { db, getSettings } from "@/lib/store";
import { DIFFICULTIES, Settings } from "@/lib/types";
export const dynamic = "force-dynamic";
export async function GET() {
  try { return Response.json(await getSettings()); }
  catch (e: any) { return Response.json({ error: e.message }, { status: 500 }); }
}
export async function POST(req: Request) {
  try {
    const b = await req.json();
    const s: Settings = {
      email: String(b.email ?? "").trim(), name: String(b.name ?? "").trim().slice(0, 40),
      difficulty: DIFFICULTIES.some((d) => d.id === b.difficulty) ? b.difficulty : "broadly-read",
      areas: Array.isArray(b.areas) ? b.areas.map(String).slice(0, 30) : [],
      extras: String(b.extras ?? "").slice(0, 300),
      everyDays: [1, 2, 3, 7].includes(Number(b.everyDays)) ? Number(b.everyDays) : 1,
    };
    if (!/^\S+@\S+\.\S+$/.test(s.email)) return Response.json({ error: "Enter a valid email address." }, { status: 400 });
    await db().set("settings", s);
    return Response.json(s);
  } catch (e: any) { return Response.json({ error: e.message }, { status: 500 }); }
}
