"use client";
import { useEffect, useState } from "react";
import { DIFFICULTIES, Result, Stats } from "@/lib/types";
import { longDate } from "@/lib/dates";

export default function History() {
  const [d, setD] = useState<{ results: Result[]; stats: Stats } | null>(null);
  const [err, setErr] = useState("");
  useEffect(() => { fetch("/api/history").then(async (r) => { const j = await r.json(); r.ok ? setD(j) : setErr(j.error); }).catch(() => setErr("Could not load history.")); }, []);
  if (err) return <main className="card"><p className="error">{err}</p></main>;
  if (!d) return <main className="card"><p className="loading">Fetching the archive...</p></main>;
  const { results, stats: s } = d;
  return (
    <main className="card">
      <h2>The Archive</h2>
      {!results.length ? <p>No completed editions yet. Finish a quiz and it will appear here.</p> : <>
        <p>{s.count} editions completed. Average {s.avg?.toFixed(0)}%. Best {s.best?.toFixed(0)}%.
          {s.strongest && ` Strongest subject: ${s.strongest.area}.`}{s.weakest && ` Weakest: ${s.weakest.area}.`}</p>
        {[...results].reverse().map((r) => (
          <div className="bar" key={r.date}>
            <span>{longDate(r.date)} ({DIFFICULTIES.find((x) => x.id === r.difficulty)?.label})</span>
            <i><b style={{ width: `${(r.score / r.total) * 100}%` }} /></i><em>{r.score}/{r.total}</em>
          </div>
        ))}
      </>}
    </main>
  );
}
