import type { Metadata, Viewport } from "next";
import Masthead from "@/components/Masthead";
import "./globals.css";
export const metadata: Metadata = {
  title: "Anne's Daily Quiz", manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, title: "Daily Quiz", statusBarStyle: "default" },
  icons: { apple: "/apple-touch-icon.png", icon: "/icon-192.png" },
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, viewportFit: "cover", themeColor: "#f4f1ea" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en-AU"><body><div className="sheet"><Masthead />{children}</div></body></html>);
}
