"use client";
import { useEffect, useState } from "react";
import { DIFFICULTIES, Edition, Result, Stats } from "@/lib/types";
import { RIGHT, WRONG, rating, tracking } from "@/lib/words";

type Summary = { result: Result; stats: Stats };
export default function Home() {
  const [ed, setEd] = useState<Edition | null>(null);
  const [err, setErr] = useState("");
  const [i, setI] = useState(0);
  const [ans, setAns] = useState<number[]>([]);
  const [view, setView] = useState<"quiz" | "results">("quiz");
  const [sum, setSum] = useState<Summary | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const r = await fetch("/api/edition"); const j = await r.json();
        if (!r.ok) throw new Error(j.error);
        const e: Edition = j.edition;
        if (j.result) {
          const h = await (await fetch("/api/history")).json();
          setAns(j.result.answers); setSum({ result: j.result, stats: h.stats }); setView("results");
        } else {
          let saved: number[] = [];
          try { saved = JSON.parse(localStorage.getItem("quiz-" + e.date) || "[]"); } catch {}
          setAns(e.questions.map((_, k) => saved[k] ?? -1));
        }
        setEd(e);
      } catch (x: any) { setErr(x.message || "Could not load today's edition."); }
    })();
  }, []);

  if (err) return <main className="card"><p className="error">{err}</p><p>Check that the connections are set up (see the README), then reload.</p></main>;
  if (!ed) return <main className="card"><p className="loading">Setting the type for today's edition. The first load of the day can take up to a minute...</p></main>;

  const q = ed.questions[i];
  const picked = ans[i];
  const answered = ans.filter((a) => a >= 0).length;
  const label = DIFFICULTIES.find((d) => d.id === ed.difficulty)?.label;

  function pick(k: number) {
    if (picked >= 0 || sum) return;
    const n = [...ans]; n[i] = k; setAns(n);
    try { localStorage.setItem("quiz-" + ed!.date, JSON.stringify(n)); } catch {}
  }
  async function finish() {
    setSaving(true);
    try {
      const r = await fetch("/api/result", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ date: ed!.date, answers: ans }) });
      const j = await r.json(); if (!r.ok) throw new Error(j.error);
      setSum(j); setView("results");
    } catch (x: any) { setErr(x.message); }
    setSaving(false);
  }

  if (view === "results" && sum) {
    const { result: r, stats } = sum;
    const pct = (r.score / r.total) * 100;
    const rt = rating(pct, r.difficulty);
    return (
      <main className="card">
        <p className="kicker">Final Edition: {label}</p>
        <h2 className="score">{r.score} / {r.total}</h2>
        <h3>{rt.head}</h3><p>{rt.line}</p>
        <h4>By subject today</h4>
        {Object.entries(r.byArea).map(([a, [c, t]]) => (
          <div className="bar" key={a}><span>{a}</span><i><b style={{ width: `${(c / t) * 100}%` }} /></i><em>{c}/{t}</em></div>
        ))}
        <h4>How you are tracking</h4>
        {tracking(stats, pct).map((t, k) => <p key={k}>{t}</p>)}
        <div className="nav"><button onClick={() => { setI(0); setView("quiz"); }}>Review the questions</button></div>
      </main>
    );
  }

  return (
    <main className="card">
      <p className="kicker">Article {i + 1} of {ed.questions.length} &nbsp;|&nbsp; {q.area} &nbsp;|&nbsp; {label}</p>
      <h2 className="q">{q.q}</h2>
      <div className="opts">
        {q.options.map((o, k) => {
          const cls = picked < 0 ? "" : k === q.answer ? "right" : k === picked ? "wrong" : "dim";
          return <button key={k} className={`opt ${cls}`} onClick={() => pick(k)} aria-pressed={picked === k}><span>{"ABCD"[k]}</span>{o}</button>;
        })}
      </div>
      {picked >= 0 && (
        <aside className="bite">
          <p><b>{picked === q.answer ? RIGHT[i % RIGHT.length] : WRONG[i % WRONG.length]}</b></p>
          {picked !== q.answer && <p>The answer is <b>{"ABCD"[q.answer]}. {q.options[q.answer]}</b>.</p>}
          <p><i>Knowledge Bite:</i> {q.bite}</p>
        </aside>
      )}
      <div className="nav">
        <button onClick={() => setI(i - 1)} disabled={i === 0}>Previous</button>
        {sum ? <button onClick={() => setView("results")}>Back to results</button>
          : answered === ed.questions.length ? <button className="primary" onClick={finish} disabled={saving}>{saving ? "Saving..." : "Finish edition"}</button>
          : <span className="count">{answered} answered</span>}
        <button onClick={() => setI(i + 1)} disabled={i === ed.questions.length - 1}>Next</button>
      </div>
    </main>
  );
}
