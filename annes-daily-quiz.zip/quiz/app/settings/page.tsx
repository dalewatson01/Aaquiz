"use client";
import { useEffect, useState } from "react";
import { AREAS, DIFFICULTIES, Settings } from "@/lib/types";

export default function SettingsPage() {
  const [s, setS] = useState<Settings | null>(null);
  const [msg, setMsg] = useState("");
  useEffect(() => { fetch("/api/settings").then(async (r) => { const j = await r.json(); r.ok ? setS(j) : setMsg(j.error); }).catch(() => setMsg("Could not load settings.")); }, []);
  if (!s) return <main className="card"><p className={msg ? "error" : "loading"}>{msg || "Loading..."}</p></main>;
  const set = (p: Partial<Settings>) => setS({ ...s, ...p });
  const toggle = (a: string) => set({ areas: s.areas.includes(a) ? s.areas.filter((x) => x !== a) : [...s.areas, a] });
  async function save() {
    setMsg("Saving...");
    const r = await fetch("/api/settings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(s) });
    const j = await r.json(); setMsg(r.ok ? "Saved. Changes apply from the next new edition (tomorrow's, unless today's is not yet written)." : j.error);
  }
  return (
    <main className="card settings">
      <h2>Editor's Desk</h2>
      <label>Recipient email<input type="email" value={s.email} onChange={(e) => set({ email: e.target.value })} /></label>
      <label>Recipient's first name<input value={s.name} onChange={(e) => set({ name: e.target.value })} /></label>
      <label>Send a new quiz every
        <select value={s.everyDays} onChange={(e) => set({ everyDays: Number(e.target.value) })}>
          <option value={1}>day</option><option value={2}>2 days</option><option value={3}>3 days</option><option value={7}>7 days</option>
        </select></label>
      <h4>Difficulty</h4>
      <div className="chips">{DIFFICULTIES.map((d) => (
        <button key={d.id} className={s.difficulty === d.id ? "chip on" : "chip"} onClick={() => set({ difficulty: d.id })}>{d.label}<small>{d.blurb}</small></button>))}</div>
      <h4>Focus areas</h4>
      <div className="chips">{AREAS.map((a) => <button key={a} className={s.areas.includes(a) ? "chip on" : "chip"} onClick={() => toggle(a)} aria-pressed={s.areas.includes(a)}>{a}</button>)}</div>
      <label>Other interests (optional)<input value={s.extras} placeholder="e.g. cricket, Scottish castles, jazz" onChange={(e) => set({ extras: e.target.value })} /></label>
      <div className="nav"><button className="primary" onClick={save}>Save settings</button></div>
      {msg && <p className="note">{msg}</p>}
    </main>
  );
}
