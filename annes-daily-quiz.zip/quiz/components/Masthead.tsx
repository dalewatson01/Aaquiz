"use client";
import Link from "next/link";
import { useState } from "react";
import { issueNo, longDate, todayKey } from "@/lib/dates";

export default function Masthead() {
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const d = todayKey();
  async function send() {
    setBusy(true); setMsg("Composing and sending. This can take up to a minute...");
    try {
      const r = await fetch("/api/send-quiz", { method: "POST" });
      const j = await r.json();
      setMsg(r.ok ? `Sent to ${j.to}.` : j.error || "Could not send.");
    } catch { setMsg("Could not reach the server."); }
    setBusy(false);
  }
  return (
    <header className="masthead">
      <h1>Anne's Daily Quiz</h1>
      <p className="tag">Broadsheet Gazette &amp; Morning Intelligence</p>
      <p className="dateline" suppressHydrationWarning>{longDate(d)} &nbsp;|&nbsp; Issue No. {issueNo(d)} &nbsp;|&nbsp; Price: Curiosity</p>
      <nav>
        <Link href="/">Today's Quiz</Link><Link href="/history">History</Link><Link href="/settings">Settings</Link>
        <button onClick={send} disabled={busy}>Send Today's Quiz to Anne</button>
      </nav>
      {msg && <p className="note" role="status">{msg}</p>}
    </header>
  );
}
