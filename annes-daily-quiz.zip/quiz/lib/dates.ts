export const todayKey = () => new Intl.DateTimeFormat("en-CA", { timeZone: "Australia/Melbourne" }).format(new Date());
export const issueNo = (d: string) => Math.max(1, Math.floor((Date.parse(d) - Date.parse("2026-11-02")) / 864e5) + 1);
export const longDate = (d: string) =>
  new Date(d + "T00:00:00Z").toLocaleDateString("en-AU", { weekday: "long", day: "numeric", month: "long", year: "numeric", timeZone: "UTC" });
export const daysBetween = (a: string, b: string) => Math.round((Date.parse(b) - Date.parse(a)) / 864e5);
