import { DIFFICULTIES, Edition } from "./types";
import { issueNo, longDate } from "./dates";

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const L = "ABCD";
const F = "Georgia,'Times New Roman',serif";

export function renderEmail(ed: Edition, name: string, appUrl?: string) {
  const diff = DIFFICULTIES.find((d) => d.id === ed.difficulty)?.label ?? ed.difficulty;
  const qs = ed.questions.map((q, n) => `<tr><td style="padding:14px 0;border-bottom:1px solid #c9c3b6;font-family:${F};color:#1c1917">
<div style="font-size:12px;color:#78716c;font-style:italic">${n + 1}. ${esc(q.area)}</div>
<div style="font-size:18px;line-height:1.4;margin:4px 0 8px"><b>${esc(q.q)}</b></div>
${q.options.map((o, k) => `<div style="font-size:16px;line-height:1.6">${L[k]}. ${esc(o)}</div>`).join("")}</td></tr>`).join("");
  const ans = ed.questions.map((q, n) => `<tr><td style="padding:10px 0;border-bottom:1px solid #c9c3b6;font-family:${F};color:#1c1917;font-size:15px;line-height:1.5">
<b>${n + 1}. ${L[q.answer]}. ${esc(q.options[q.answer])}</b><br><i>${esc(q.bite)}</i></td></tr>`).join("");
  const button = appUrl ? `<p style="text-align:center;margin:18px 0"><a href="${appUrl}" style="display:inline-block;padding:14px 26px;background:#1c1917;color:#f4f1ea;font-family:${F};font-size:16px;text-decoration:none">Play it in the app and track your score</a></p>` : "";
  return `<!doctype html><html><body style="margin:0;padding:12px 0;background:#e7e2d6">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:640px;background:#f4f1ea;border:4px double #1c1917"><tr><td style="padding:22px 20px;font-family:${F};color:#1c1917">
<div style="text-align:center;border-bottom:3px double #1c1917;padding-bottom:12px">
<div style="font-size:32px;font-weight:bold;line-height:1.1">Anne's Daily Quiz</div>
<div style="font-size:13px;font-style:italic;margin-top:4px">Broadsheet Gazette &amp; Morning Intelligence</div>
<div style="font-size:12px;margin-top:8px">${longDate(ed.date)} &nbsp;|&nbsp; Issue No. ${issueNo(ed.date)} &nbsp;|&nbsp; Price: Curiosity</div></div>
<p style="font-size:16px;line-height:1.5">Good morning${name ? ", " + esc(name) : ""}. Today's edition is set at <b>${diff}</b>: fifteen questions, answers below the fold.</p>
${button}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0">${qs}</table>
<div style="text-align:center;font-size:20px;font-weight:bold;border-top:3px double #1c1917;border-bottom:3px double #1c1917;padding:8px;margin:22px 0 6px">Answers &amp; Knowledge Bites</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0">${ans}</table>
</td></tr></table></td></tr></table></body></html>`;
}
