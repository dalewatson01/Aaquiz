import Anthropic from "@anthropic-ai/sdk";
import { DIFFICULTIES, Edition, Question } from "./types";
import { issueNo } from "./dates";
import { db, getSettings } from "./store";

const GUIDE: Record<string, string> = {
  novice: "Gentle and well known: facts most curious teenagers or casual quiz-goers would know.",
  curious: "Moderate: what a keen, educated general reader would know or could reason out.",
  "broadly-read": "Challenging: well-read adult, strong pub-quiz player. Some questions should need real recall.",
  wicked: "Very hard: obscure details, specialist knowledge and clever, plausible wrong options.",
};
const ok = (q: any): q is Question =>
  q && typeof q.q === "string" && Array.isArray(q.options) && q.options.length === 4 &&
  q.options.every((o: any) => typeof o === "string") && Number.isInteger(q.answer) && q.answer >= 0 && q.answer < 4 &&
  typeof q.bite === "string" && typeof q.area === "string";

export async function getEdition(date: string): Promise<Edition> {
  const cached = await db().get<Edition>(`edition:${date}`);
  if (cached) return cached;
  const s = await getSettings();
  const recent = await db().lrange<string>("recent", 0, 79);
  const label = DIFFICULTIES.find((d) => d.id === s.difficulty)?.label;
  const prompt = `Write a general-knowledge quiz of exactly 15 multiple-choice questions for a daily newspaper-style quiz.
Difficulty: ${label}. ${GUIDE[s.difficulty]}
Focus areas (spread questions evenly across these): ${s.areas.join("; ") || "general knowledge"}.
${s.extras ? `Extra interests to weave in where natural: ${s.extras}.` : ""}
Rules: factually accurate and unambiguous with exactly one correct option; four plausible options; vary which position is correct; Australian spelling; no questions about events after 2025.
Each "bite" is a 2-3 sentence "Knowledge Bite": why the answer is right plus one interesting related fact.
Do not repeat or closely paraphrase these recent questions: ${recent.join(" | ") || "none"}.
Reply with ONLY a JSON array, no prose, no code fences. Each item: {"area": string (one of the focus areas), "q": string, "options": [4 strings, no letter prefixes], "answer": 0-3 index of the correct option, "bite": string}.`;
  const msg = await new Anthropic().messages.create({
    model: "claude-sonnet-5-5", max_tokens: 8000, messages: [{ role: "user", content: prompt }],
  });
  const text = msg.content.map((b) => (b.type === "text" ? b.text : "")).join("");
  const raw = JSON.parse(text.slice(text.indexOf("["), text.lastIndexOf("]") + 1));
  const questions = (raw as unknown[]).filter(ok).slice(0, 15);
  if (questions.length < 15) throw new Error("The question writer returned an incomplete edition. Please try again.");
  const edition: Edition = { date, issue: issueNo(date), difficulty: s.difficulty, questions };
  await db().set(`edition:${date}`, edition, { ex: 60 * 60 * 24 * 90 });
  await db().lpush("recent", ...questions.map((q) => q.q));
  await db().ltrim("recent", 0, 149);
  return edition;
}
