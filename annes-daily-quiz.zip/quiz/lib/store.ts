import { Redis } from "@upstash/redis";
import { DEFAULT_SETTINGS, Result, Settings, Stats } from "./types";

let _r: Redis | undefined;
export function db() {
  if (!_r) {
    const url = process.env.UPSTASH_REDIS_REST_URL ?? process.env.KV_REST_API_URL;
    const token = process.env.UPSTASH_REDIS_REST_TOKEN ?? process.env.KV_REST_API_TOKEN;
    if (!url || !token) throw new Error("Storage is not connected. Add the Upstash Redis integration to the Vercel project.");
    _r = new Redis({ url, token });
  }
  return _r;
}
export async function getSettings(): Promise<Settings> {
  const s = await db().get<Settings>("settings");
  return { ...DEFAULT_SETTINGS, ...(s ?? {}) };
}
export async function getResults(): Promise<Result[]> {
  const h = await db().hgetall<Record<string, Result>>("results");
  return Object.values(h ?? {}).sort((a, b) => a.date.localeCompare(b.date));
}
export function computeStats(rs: Result[]): Stats {
  const pct = (r: Result) => (r.score / r.total) * 100;
  const avg = (a: Result[]) => (a.length ? a.reduce((s, r) => s + pct(r), 0) / a.length : null);
  const byArea: Record<string, [number, number]> = {};
  for (const r of rs) for (const [k, [c, t]] of Object.entries(r.byArea)) {
    const x = (byArea[k] ??= [0, 0]); x[0] += c; x[1] += t;
  }
  const ranked = Object.entries(byArea).filter(([, v]) => v[1] >= 3)
    .map(([area, v]) => ({ area, pct: (v[0] / v[1]) * 100 })).sort((a, b) => b.pct - a.pct);
  return {
    count: rs.length, avg: avg(rs), recent: avg(rs.slice(-7)), previous: avg(rs.slice(-14, -7)),
    best: rs.length ? Math.max(...rs.map(pct)) : null,
    strongest: ranked[0] ?? null, weakest: ranked.length > 1 ? ranked[ranked.length - 1] : null,
  };
}
