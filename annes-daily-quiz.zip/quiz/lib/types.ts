export type Difficulty = "novice" | "curious" | "broadly-read" | "wicked";
export const DIFFICULTIES: { id: Difficulty; label: string; blurb: string }[] = [
  { id: "novice", label: "Novice", blurb: "Friendly, widely known facts" },
  { id: "curious", label: "Curious", blurb: "For the keen general reader" },
  { id: "broadly-read", label: "Broadly Read", blurb: "Pub-quiz champion territory" },
  { id: "wicked", label: "Wicked", blurb: "Obscure, devious, delightful" },
];
export const AREAS = [
  "Science", "Space & Astronomy", "Nature & Environment", "Horticulture & Gardening",
  "Medicine & the Body", "Technology & Inventions", "World History", "European History",
  "Australian History", "US History", "Ancient Civilisations", "Politics & Government",
  "Current Affairs", "World Geography", "Australian Geography", "Victoria & Melbourne",
  "Travel & Cultures", "Literature", "Poetry & Language", "Art & Architecture",
  "Music", "Film & Television", "Food & Drink", "Sport", "Mythology & Religion",
  "Economics & Business",
];
export type Settings = { email: string; name: string; difficulty: Difficulty; areas: string[]; extras: string; everyDays: number };
export const DEFAULT_SETTINGS: Settings = {
  email: "annecolvin01@gmail.com", name: "Anne", difficulty: "broadly-read",
  areas: ["Science", "World History", "World Geography", "Literature", "Horticulture & Gardening"],
  extras: "", everyDays: 1,
};
export type Question = { q: string; options: string[]; answer: number; bite: string; area: string };
export type Edition = { date: string; issue: number; difficulty: Difficulty; questions: Question[] };
export type Result = { date: string; difficulty: Difficulty; score: number; total: number; byArea: Record<string, [number, number]>; answers: number[] };
export type Stats = {
  count: number; avg: number | null; recent: number | null; previous: number | null; best: number | null;
  strongest: { area: string; pct: number } | null; weakest: { area: string; pct: number } | null;
};
