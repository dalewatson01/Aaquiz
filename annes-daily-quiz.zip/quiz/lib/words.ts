import { DIFFICULTIES, Difficulty, Stats } from "./types";

export const RIGHT = ["Splendid, spot on.", "Correct. Nicely read.", "Quite right. A fine piece of recall.", "Yes. The gazette salutes you.", "Well done. That one was not easy."];
export const WRONG = [
  "Not this time, but that is a sneaky one. Now you will remember it.",
  "Close, and a good guess. Even editors miss this one.",
  "A miss, but a useful one: that fact is yours now.",
  "Not quite. Plenty of sharp minds trip on this. On to the next.",
  "Unlucky. The best quizzers are made of these misses.",
];
export function rating(pct: number, d: Difficulty) {
  const lvl = DIFFICULTIES.find((x) => x.id === d)?.label ?? "";
  if (pct === 100) return { head: "Stop the presses: a perfect edition!", line: `Fifteen from fifteen on ${lvl}. Remarkable.` };
  if (pct >= 80) return { head: "A distinguished performance", line: `Excellent form for ${lvl} level. Hard to ask for more.` };
  if (pct >= 60) return { head: "A creditable showing", line: `A solid result on ${lvl}: more right than wrong, with room to climb.` };
  if (pct >= 40) return { head: "A respectable effort", line: `${lvl} level bites back sometimes. Every Knowledge Bite above makes the next edition easier.` };
  return { head: "A tough edition, bravely tackled", line: `Today's questions were a stiff test. Keep reading the bites; scores climb quickly with practice.` };
}
export function tracking(s: Stats, pct: number) {
  const out: string[] = [];
  if (s.count <= 1) return ["This is the first edition on the record: a baseline to build on."];
  if (s.recent != null && s.previous != null) {
    const d = s.recent - s.previous;
    out.push(Math.abs(d) < 3 ? "Your last week is steady against the week before." : d > 0 ? `Your last week is up ${d.toFixed(0)} points on the week before. Lovely trend.` : `Your last week is down ${(-d).toFixed(0)} points on the week before. Just a dip; keep going.`);
  }
  if (s.avg != null) out.push(`Across ${s.count} editions you average ${s.avg.toFixed(0)}%; today was ${pct.toFixed(0)}%.`);
  if (s.best != null && pct >= s.best) out.push("That ties or sets your personal best.");
  if (s.strongest) out.push(`Strongest ground so far: ${s.strongest.area} (${s.strongest.pct.toFixed(0)}%).`);
  if (s.weakest) out.push(`Room to grow: ${s.weakest.area} (${s.weakest.pct.toFixed(0)}%).`);
  return out;
}
